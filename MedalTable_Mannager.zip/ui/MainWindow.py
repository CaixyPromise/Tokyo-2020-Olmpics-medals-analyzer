import tkinter.ttk as ttk
import tkinter as tk

class MainWindow(ttk.Frame):
    def __init__(self, parent, **kwargs):
        ttk.Frame.__init__(self, parent, **kwargs)
        
